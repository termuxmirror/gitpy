from setuptools import setup, find_packages

setup(
    name='gitpy',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        # Hier kannst du Abhängigkeiten deines Pakets auflisten, falls vorhanden
    ],
    entry_points={
        'console_scripts': [
            'gitpy-main = gitpy.main:main'
        ]
    },
    author='termuxmirror',
    author_email='termux-mirror@outlook.de',
    description='A Python package for working with Git repositories.',
    url='https://github.com/termuxmirror/gitpy',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)

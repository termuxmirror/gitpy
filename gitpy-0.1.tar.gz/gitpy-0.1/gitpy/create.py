import os
import subprocess

def create_repository():
    repo_folder = os.path.expanduser("~/.repository")
    if not os.path.exists(repo_folder):
        os.makedirs(repo_folder)

    repo_name = input("Enter the repository name: ")
    repo_path = os.path.join(repo_folder, repo_name)

    if os.path.exists(repo_path):
        print("Repository already exists.")
        return

    os.makedirs(repo_path)
    os.chdir(repo_path)
    subprocess.run(["git", "init"])  # Initialisiert das Git-Repository

    # Frage nach der URL des Remote-Repositorys und verknüpfe es
    remote_url = input("Enter the URL of the remote repository: ")
    subprocess.run(["git", "remote", "add", "origin", remote_url])

    print(f"Repository '{repo_name}' created successfully and linked to remote repository.")

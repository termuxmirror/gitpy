import os
import subprocess

def push_repository(local_repo_name):
    repo_folder = os.path.expanduser("~/.repository")
    repository_path = os.path.join(repo_folder, local_repo_name)
    
    if not os.path.exists(repository_path):
        print("Repository does not exist.")
        return
    
    os.chdir(repository_path)
    
    # Laden von Benutzerinformationen aus der .gitrc-Datei
    gitrc_path = os.path.expanduser("~/.gitrc")
    with open(gitrc_path, "r") as file:
        lines = file.readlines()
        for line in lines:
            if line.startswith("username="):
                github_username = line.split("=")[1].strip()
            elif line.startswith("password="):
                github_password = line.split("=")[1].strip()
            elif line.startswith("email="):
                github_email = line.split("=")[1].strip()

    # Setzen der Git-Benutzerinformationen
    subprocess.run(["git", "config", "--global", "user.name", github_username])
    subprocess.run(["git", "config", "--global", "user.password", github_password])
    subprocess.run(["git", "config", "--global", "user.email", github_email])
    
    # Hinzufügen, Committen und Pushen der Änderungen
    subprocess.run(["git", "add", "."])
    subprocess.run(["git", "commit", "-m", "Pushing changes"])
    push_choice = input("Do you want to push the changes? (y/n): ").lower()
    if push_choice == "y":
        subprocess.run(["git", "push", "origin", "master"])
    elif push_choice == "n":
        print("Changes not pushed.")
    else:
        print("Invalid input. Changes not pushed.")

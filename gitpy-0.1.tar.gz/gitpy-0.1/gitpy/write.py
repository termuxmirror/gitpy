import os

def write_repository(repo_name):
    repo_folder = os.path.expanduser("~/.repository")
    repo_path = os.path.join(repo_folder, repo_name)
    
    if not os.path.exists(repo_path):
        print("Repository does not exist.")
        return
    
    os.chdir(repo_path)
    os.system("$SHELL")

import os

def set_user_info():
    github_username = input("Enter your GitHub username: ")
    github_password = input("Enter your GitHub password: ")
    github_email = input("Enter your GitHub email: ")
    
    gitrc_path = os.path.expanduser("~/.gitrc")
    with open(gitrc_path, "w") as file:
        file.write(f"username={github_username}\n")
        file.write(f"password={github_password}\n")
        file.write(f"email={github_email}\n")
    print("User information saved successfully.")
